this project is done as one of graded learning assignments of nationnal school of computer science


----what does the code do?
the project is mainly a boycotting app with delivery elements
a user can sign up or login(if they already signed up)
then they can browse either ordering takeout(fast food) or buying merchandise(electronics,snacks or drinks)
if a product is boycotted (because of the the war between israel and palastine), replacement products will be suggested
and once a delivery is commited, the user can track all deliveries (percentages) and leave feedback


---key learning focus of the project
*getting familiar with basic c language
*queue manipulation
*getting used to pointer
*file handeling
*cmd interface
*learning time.h functions


---IMPORTANT NOTE: to make the code work, modify this line of the code
const char configpath[100]="path to----->/config files/";
replace what's qouted with the ABSOLUTE PATH to the folder "config files" and add "/"
example: "C:/User/c project/config files/"


---feel free to play around with the code and modify it(integrate store items logic for example, add more examples/types of boycotted products)